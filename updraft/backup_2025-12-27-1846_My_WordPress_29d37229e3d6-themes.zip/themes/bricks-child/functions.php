<?php 
/**
 * Register/enqueue custom scripts and styles
 */
add_action( 'wp_enqueue_scripts', function() {
	// Enqueue your files on the canvas & frontend, not the builder panel. Otherwise custom CSS might affect builder)
	if ( ! bricks_is_builder_main() ) {
		wp_enqueue_style( 'bricks-child', get_stylesheet_uri(), ['bricks-frontend'], filemtime( get_stylesheet_directory() . '/style.css' ) );
	}
} );

/**
 * Register custom elements
 */
add_action( 'init', function() {
  $element_files = [
    __DIR__ . '/elements/title.php',
  ];

  foreach ( $element_files as $file ) {
    \Bricks\Elements::register_element( $file );
  }
}, 11 );

/**
 * Add text strings to builder
 */
add_filter( 'bricks/builder/i18n', function( $i18n ) {
  // For element category 'custom'
  $i18n['custom'] = esc_html__( 'Custom', 'bricks' );

  return $i18n;
} );

function add_inline_script() {

    // Make sure GSAP is enqueued first
    wp_enqueue_script(
        'gsap',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
        [],
        null,
        true
    );

    wp_add_inline_script('gsap', <<<JS
    window.addEventListener('load', () => {

        // GSAP Timeline
        const tl = gsap.timeline();

        // Birds animation
        tl.to('.mountain', { opacity: 1, duration: 1.5, ease: 'power3.out' }, 0);

        

        // Headlines and text
        tl.to('.heading-1', { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }, 0.6);
        tl.to('.heading-2', { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }, 0.7);
        tl.to('.text-1', { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }, 0.8);
        tl.to('.text-2', { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }, 0.9);
        tl.to('.spotlight-animation-container .bricks-background-primary', { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }, 1);

        // Birds
        tl.to('.birds2', { left: '46%', duration: 1, ease: 'power3.out' }, 1.2);
        tl.to('.birds1', { left: '60%', duration: 1, ease: 'power3.out' }, 1.2);

        // Hiking
        tl.to('.hiking', { right: '-3%', duration: 1, ease: 'none' }, 1)
          .to('.hiking', { right: '-4%', duration: 1, ease: 'none' }, '>')
          .to('.hiking', { right: '-3%', duration: 1, ease: 'none' }, '>');

        // --------------------------
        // Mouse follow effect AFTER timeline
        // --------------------------
        tl.call(() => {
            const elements = [
                { el: document.querySelector('.birds1'), factor: 0.03 },
                { el: document.querySelector('.birds2'), factor: 0.02 },
                { el: document.querySelector('.hiking'), factor: 0.01 }
            ];

            window.addEventListener('mousemove', (e) => {
                const centerX = window.innerWidth / 2;
                const centerY = window.innerHeight / 2;

                elements.forEach(({el, factor}) => {
                    if (!el) return;

                    const xMove = (e.clientX - centerX) * factor;
                    const yMove = (e.clientY - centerY) * factor;

                    gsap.to(el, {
                        x: xMove,
                        y: yMove,
                        duration: 0.5,
                        ease: "power3.out",
                        overwrite: "auto"
                    });
                });
            });
        });
    });
JS
    );
}
add_action('wp_enqueue_scripts', 'add_inline_script');
